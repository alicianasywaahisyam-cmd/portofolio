import javafx.application.Application;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Spinner;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CustomerDashboard extends Application {

    private static final String URL = "jdbc:mysql://localhost:3306/floraartistry";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    private Stage window;
    private Scene buyProductScene, cartScene, loginScene;
    private MenuBar menuBar;
    private MenuItem buyProductMenuItem, cartMenuItem, logoutMenuItem;

    private TableView<Product> productTable;
    private Label productNameLabel, productTypeLabel, productPriceLabel, flowerDetailLabel;
    private Product selectedProduct;

    private String currentUser; // Untuk menyimpan username pengguna saat ini
    private String currentUserID;

    //Untuk menyesuaikan current user ada di greetings label
    private String fetchCurrentUsername(String userID) {
        String username = null;
        String query = "SELECT UserName FROM MsUser WHERE UserID = ?";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, userID);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    username = resultSet.getString("UserName");
                } else {
                    System.err.println("No user found for UserID: " + userID);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showErrorAlert11("Database Error", "Failed to fetch username: " + e.getMessage());
        }

        return username != null ? username : "Guest"; // Default ke "Guest" jika null
    }


private ObservableList<Product> fetchProductsFromDatabase() {
    ObservableList<Product> productList = FXCollections.observableArrayList();
    String query = "SELECT FlowerName, FlowerType, FlowerPrice FROM MsFlower";

    try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
         PreparedStatement preparedStatement = connection.prepareStatement(query);
         ResultSet resultSet = preparedStatement.executeQuery()) {

        while (resultSet.next()) {
            String name = resultSet.getString("FlowerName");
            String type = resultSet.getString("FlowerType");
            String price = String.valueOf(resultSet.getDouble("FlowerPrice"));
            productList.add(new Product(name, type, price, 0));
        }

    } catch (SQLException e) {
        showErrorAlert11("Database Error", "Failed to fetch products: " + e.getMessage());
    }

    return productList;
}



private ObservableList<Product> cartList = FXCollections.observableArrayList();

@Override
public void start(Stage primaryStage) {
    window = primaryStage;
    UserDAO userDAO = new UserDAO(Connect.getConnection());

    // Membuat MenuBar dengan Menu untuk navigasi
    menuBar = new MenuBar();
    Menu pageMenu = new Menu("Page");

    buyProductMenuItem = new MenuItem("Buy Flower");
    cartMenuItem = new MenuItem("Cart");
    logoutMenuItem = new MenuItem("Log Out");

    // Menambahkan MenuItem ke Menu
    pageMenu.getItems().addAll(buyProductMenuItem, cartMenuItem, logoutMenuItem);
    menuBar.getMenus().add(pageMenu);

    // Event handling untuk navigasi
    buyProductMenuItem.setOnAction(e -> {
        if (window.getScene() != buyProductScene) {
            createBuyProductScene(currentUser);
            window.setScene(buyProductScene);
        }
    });

    cartMenuItem.setOnAction(e -> {
        if (window.getScene() != cartScene) {
            createCartScene();
            window.setScene(cartScene);
        }
    });

    logoutMenuItem.setOnAction(e -> {
        if (window.getScene() != loginScene) {
            createLoginScene();
            window.setScene(loginScene);
        }
    });

    // Scene awal kosong dengan MenuBar
    BorderPane initialPane = new BorderPane();
    initialPane.setTop(menuBar);
    Scene initialScene = new Scene(initialPane, 400, 300);
    window.setScene(initialScene);
    window.setTitle("Customer Navigation");
    window.show();
}



// Membuat Scene untuk Buy Product
private void createBuyProductScene(String userID) {
    // Memanggil UserDAO untuk mengambil currentUser berdasarkan userID
    UserDAO userDAO = new UserDAO(Connect.getConnection()); 
    currentUser = userDAO.getUserNameByID(userID);

    // Jaga-jaga kalau fallback
    if (currentUser == null || currentUser.isEmpty()) {
        currentUser = "Guest";
    }

    BorderPane buyProductPane = new BorderPane();
    buyProductPane.setTop(menuBar);
    
    Label greetingLabel = new Label("Welcome, " + currentUser);
    greetingLabel.setFont(new Font("Arial", 16));
    greetingLabel.setAlignment(Pos.TOP_LEFT);


    Label productListLabel = new Label("Product List");
    productListLabel.setFont(new Font("Arial", 20));
    productListLabel.setStyle("-fx-font-weight: bold;");
    productListLabel.setAlignment(Pos.TOP_LEFT);


    productTable = new TableView<>();
    productTable.setPrefWidth(300);
    productTable.setPrefHeight(200);

    TableColumn<Product, String> nameColumn = new TableColumn<>("Flower Name");
    nameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());

    TableColumn<Product, String> typeColumn = new TableColumn<>("Flower Type");
    typeColumn.setCellValueFactory(cellData -> cellData.getValue().typeProperty());

    TableColumn<Product, String> priceColumn = new TableColumn<>("Flower Price");
    priceColumn.setCellValueFactory(cellData -> cellData.getValue().priceProperty());

    productTable.getColumns().addAll(nameColumn, typeColumn, priceColumn);

    ObservableList<Product> productList = fetchProductsFromDatabase();
    productTable.setItems(productList);

    productTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
        selectedProduct = newSelection; // Update produk yang dipilih
        if (selectedProduct != null) {
            productNameLabel.setText("Flower Name: " + selectedProduct.getName());
            productTypeLabel.setText("Flower Type: " + selectedProduct.getType());
            productPriceLabel.setText("Price: $" + selectedProduct.getPrice());
        } else {
            // Reset label jika tidak ada produk yang dipilih
            productNameLabel.setText("Flower Name: ");
            productTypeLabel.setText("Flower Type: ");
            productPriceLabel.setText("Price: ");
        }
    });


    flowerDetailLabel = new Label("Flower Detail:");
    flowerDetailLabel.setFont(new Font("Arial", 18));

    productNameLabel = new Label("Flower Name: ");
    productTypeLabel = new Label("Flower Type: ");
    productPriceLabel = new Label("Price: ");

    Button addToCartButton = new Button("Add to Cart");
    addToCartButton.setOnAction(e -> {
        if (selectedProduct == null) { // Jika tidak ada produk yang dipilih
            showAlert11("Add to Cart Failed", "No flower selected", Alert.AlertType.ERROR);
        } else {
            openAddToCartWindow();
        }
    });

    VBox flowerDetailVBox = new VBox(10);
    flowerDetailVBox.setAlignment(Pos.TOP_LEFT);
    flowerDetailVBox.getChildren().addAll(flowerDetailLabel, productNameLabel, productTypeLabel, productPriceLabel, addToCartButton);

    HBox mainLayout = new HBox(20);
    mainLayout.setAlignment(Pos.TOP_LEFT);
    mainLayout.getChildren().addAll(productTable, flowerDetailVBox);

    VBox vbox = new VBox(10);
    vbox.setAlignment(Pos.TOP_LEFT);
    vbox.getChildren().addAll(productListLabel, greetingLabel, mainLayout);

    buyProductPane.setCenter(vbox);

    buyProductScene = new Scene(buyProductPane, 800, 400);
    window.setTitle("Buy Product");
}

private void showErrorAlert11(String title, String message) {
    Alert alert = new Alert(Alert.AlertType.ERROR);
    alert.setTitle(title);
    alert.setContentText(message);
    alert.showAndWait();
}

private void showAlert11(String title, String message, Alert.AlertType alertType) {
    Alert alert = new Alert(alertType);
    alert.setTitle(title);
    alert.setContentText(message);
    alert.showAndWait();
}

//Modifikasi pada openAddToCartWindow()
private void openAddToCartWindow() {
    if (selectedProduct == null) return;

    Stage addToCartWindow = new Stage();
    addToCartWindow.setTitle("Add to Cart");

    Label flowerNameLabel = new Label("Flower Name: " + selectedProduct.getName());
    Label flowerTypeLabel = new Label("Flower Type: " + selectedProduct.getType());
    Label flowerPriceLabel = new Label("Price: $" + selectedProduct.getPrice());

    int initialQuantity = getCartProductQuantity(selectedProduct);
    Spinner<Integer> quantitySpinner = new Spinner<>(1, 100, initialQuantity > 0 ? initialQuantity : 1);
    quantitySpinner.setEditable(true);

    Button addButton = new Button("Add to Cart");
    addButton.setOnAction(e -> {
        int quantity = quantitySpinner.getValue();
        addProductToCart(selectedProduct, quantity);
        addToCartWindow.close();
        showAlert11("Success", selectedProduct.getName() + " has been added/updated in the cart.", Alert.AlertType.INFORMATION);

       
        updateCartList();
    });

    Button cancelButton = new Button("Cancel");
    cancelButton.setOnAction(e -> addToCartWindow.close());

    VBox layout = new VBox(10, flowerNameLabel, flowerTypeLabel, flowerPriceLabel, quantitySpinner, addButton, cancelButton);
    layout.setAlignment(Pos.CENTER);

    Scene addToCartScene = new Scene(layout, 300, 250);
    addToCartWindow.setScene(addToCartScene);
    addToCartWindow.show();
}

private void updateCartList() {
    cartList.clear(); // Bersihkan daftar sebelumnya
    String query = "SELECT f.FlowerName, f.FlowerType, f.FlowerPrice, c.Quantity " +
                   "FROM MsCart c " +
                   "JOIN MsFlower f ON c.FlowerID = f.FlowerID " +
                   "WHERE c.UserID = ?";
    try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
         PreparedStatement statement = connection.prepareStatement(query)) {
        statement.setString(1, currentUser);
        ResultSet resultSet = statement.executeQuery();
        while (resultSet.next()) {
            String name = resultSet.getString("FlowerName");
            String type = resultSet.getString("FlowerType");
            String price = String.valueOf(resultSet.getDouble("FlowerPrice"));
            int quantity = resultSet.getInt("Quantity");
            cartList.add(new Product(name, type, price, quantity));
        }
    } catch (SQLException e) {
        showErrorAlert11("Database Error", "Failed to fetch cart items: " + e.getMessage());
    }
}

//Mendapatkan quantity
private int getCartProductQuantity(Product product) {
 String query = "SELECT Quantity FROM MsCart WHERE UserID = ? AND FlowerID = (SELECT FlowerID FROM MsFlower WHERE FlowerName = ?)";
 try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
      PreparedStatement statement = connection.prepareStatement(query)) {
     statement.setString(1, currentUser);
     statement.setString(2, product.getName());
     ResultSet resultSet = statement.executeQuery();
     if (resultSet.next()) {
         return resultSet.getInt("Quantity");
     }
 } catch (SQLException e) {
     showErrorAlert11("Database Error", "Failed to fetch product quantity: " + e.getMessage());
 }
 return 0;
}




//Menambahkan atau memperbarui produk di keranjang (MsCart)
private void addProductToCart(Product product, int quantity) {

    String selectQuery = "SELECT Quantity FROM MsCart WHERE UserID = ? AND FlowerID = (SELECT FlowerID FROM MsFlower WHERE FlowerName = ?)";
    String updateQuery = "UPDATE MsCart SET Quantity = ? WHERE UserID = ? AND FlowerID = (SELECT FlowerID FROM MsFlower WHERE FlowerName = ?)";
    String insertQuery = "INSERT INTO MsCart (UserID, FlowerID, Quantity) VALUES (?, (SELECT FlowerID FROM MsFlower WHERE FlowerName = ?), ?)";

    try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
        connection.setAutoCommit(false);

        try (PreparedStatement selectStatement = connection.prepareStatement(selectQuery)) {
            selectStatement.setString(1, currentUser);
            selectStatement.setString(2, product.getName());
            ResultSet resultSet = selectStatement.executeQuery();

            if (resultSet.next()) {
                int newQuantity = resultSet.getInt("Quantity") + quantity;
                try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
                    updateStatement.setInt(1, newQuantity);
                    updateStatement.setString(2, currentUser);
                    updateStatement.setString(3, product.getName());
                    updateStatement.executeUpdate();
                }
            } else {
                try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery)) {
                    insertStatement.setString(1, currentUser);
                    insertStatement.setString(2, product.getName());
                    insertStatement.setInt(3, quantity);
                    insertStatement.executeUpdate();
                }
            }
        }

        connection.commit();
    } catch (SQLException e) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            connection.rollback(); // Rollback pada kegagalan
        } catch (SQLException rollbackEx) {
            rollbackEx.printStackTrace();
        }
        showErrorAlert11("Database Error", "Failed to add/update product in cart: " + e.getMessage());
    }
}



private void showAlert1(String title, String message, Alert.AlertType alertType) {
    Alert alert = new Alert(alertType);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.showAndWait();
}



// Membuat Scene untuk Cart
private void createCartScene() {
    BorderPane cartPane = new BorderPane();
    cartPane.setTop(menuBar); 

   
    Label cartListLabel = new Label("Your Cart List");
    cartListLabel.setFont(new Font("Arial", 20));
    cartListLabel.setStyle("-fx-font-weight: bold;");

   
    TableView<Product> cartTable = new TableView<>();
    cartTable.setPrefWidth(500);
    cartTable.setPrefHeight(200);

    TableColumn<Product, String> nameColumn = new TableColumn<>("Name");
    nameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());

    TableColumn<Product, String> typeColumn = new TableColumn<>("Type");
    typeColumn.setCellValueFactory(cellData -> cellData.getValue().typeProperty());

    TableColumn<Product, String> priceColumn = new TableColumn<>("Price");
    priceColumn.setCellValueFactory(cellData -> cellData.getValue().priceProperty());

    TableColumn<Product, Integer> quantityColumn = new TableColumn<>("Quantity");
    quantityColumn.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getQuantity()).asObject());

    TableColumn<Product, String> subTotalColumn = new TableColumn<>("Total");
    subTotalColumn.setCellValueFactory(cellData -> new SimpleStringProperty(String.valueOf(
            cellData.getValue().getQuantity() * Double.parseDouble(cellData.getValue().getPrice()))));

    cartTable.getColumns().addAll(nameColumn, typeColumn, priceColumn, quantityColumn, subTotalColumn);

    cartTable.setItems(cartList);
    

    double grandTotal = cartList.stream()
            .mapToDouble(product -> product.getQuantity() * Double.parseDouble(product.getPrice()))
            .sum();
    Label grandTotalLabel = new Label("Grand Total: " + grandTotal);
    
    cartList.addListener((ListChangeListener<Product>) change -> {
        double newGrandTotal = cartList.stream()
            .mapToDouble(product -> product.getQuantity() * Double.parseDouble(product.getPrice()))
            .sum();
        grandTotalLabel.setText("Grand Total: " + String.format("$%.2f", newGrandTotal));
    });

 
    Button checkoutButton = new Button("Checkout");
    checkoutButton.setOnAction(e -> {
        if (cartList.isEmpty()) {
            showAlert11("Error", "Your cart is empty.", Alert.AlertType.ERROR);
        } else {
            // Handle checkout logic
            String transactionID = generateTransactionID();
            addTransactionToDatabase(transactionID, cartList);
            cartList.clear();
            cartTable.setItems(cartList);
            showAlert11("Success", "Your transaction was successful. Transaction ID: " + transactionID, Alert.AlertType.INFORMATION);
        }
    });

   
    VBox detailLayout = new VBox(5);

 
    Label nameLabel = new Label("Name: ");
    Label typeLabel = new Label("Type: ");
    Label priceLabel = new Label("Price: ");
    Label quantityLabel = new Label("Quantity: ");
    Label subTotalLabel = new Label("Subtotal: ");

   
    detailLayout.getChildren().addAll(nameLabel, typeLabel, priceLabel, quantityLabel, subTotalLabel);


    cartTable.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, selectedProduct) -> {
        if (selectedProduct != null) {
            nameLabel.setText("Name: " + selectedProduct.getName());
            typeLabel.setText("Type: " + selectedProduct.getType());
            priceLabel.setText("Price: $" + selectedProduct.getPrice());
            quantityLabel.setText("Quantity: " + selectedProduct.getQuantity());
            double subtotal = selectedProduct.getQuantity() * Double.parseDouble(selectedProduct.getPrice());
            subTotalLabel.setText(String.format("Subtotal: $%.2f", subtotal));
        }
    });

    
    VBox cartVBox = new VBox(10, cartListLabel, cartTable, grandTotalLabel, checkoutButton);
    HBox mainLayout = new HBox(10, cartVBox, detailLayout);
    mainLayout.setPadding(new Insets(10));

    cartPane.setCenter(mainLayout);

   
    cartScene = new Scene(cartPane, 800, 400);
    window.setScene(cartScene);
}


private String generateTransactionID() {
    String prefix = "TR"; 
    String query = "SELECT TransactionID FROM TransactionHeader";
    int maxId = 0; 

    try (Connection connection = Connect.getConnection();
         Statement statement = connection.createStatement();
         ResultSet resultSet = statement.executeQuery(query)) {

        while (resultSet.next()) {
            String currentId = resultSet.getString("TransactionID");

            
            if (currentId.startsWith(prefix)) {
                try {
                    int currentNumber = Integer.parseInt(currentId.substring(prefix.length()));
                    maxId = Math.max(maxId, currentNumber);
                } catch (NumberFormatException e) {
                    System.err.println("ID tidak valid: " + currentId);
                }
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

   
    int newId = maxId + 1;
    return prefix + newId;
}





private void addTransactionToDatabase(String transactionID, ObservableList<Product> cartList) {
    String insertHeaderQuery = "INSERT INTO TransactionHeader (TransactionID, UserID) VALUES (?, ?)";
    String insertDetailQuery = "INSERT INTO TransactionDetail (TransactionID, FlowerID, Quantity) " +
                                "VALUES (?, (SELECT FlowerID FROM MsFlower WHERE FlowerName = ?), ?)";

    try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
        
        connection.setAutoCommit(false);

        
        try (PreparedStatement headerStatement = connection.prepareStatement(insertHeaderQuery)) {
            headerStatement.setString(1, transactionID);
            headerStatement.setString(2, currentUser);
            headerStatement.executeUpdate();
        }

       
        try (PreparedStatement detailStatement = connection.prepareStatement(insertDetailQuery)) {
            for (Product product : cartList) {
                detailStatement.setString(1, transactionID);
                detailStatement.setString(2, product.getName());
                detailStatement.setInt(3, product.getQuantity());
                detailStatement.addBatch();
            }
            detailStatement.executeBatch();
        }

        
        clearCart(connection);

        
        connection.commit();
    } catch (SQLException e) {
        showErrorAlert11("Database Error", "Failed to complete transaction: " + e.getMessage());
    }
}

private void clearCart(Connection connection) throws SQLException {
    String deleteCartQuery = "DELETE FROM MsCart WHERE UserID = ?";
    try (PreparedStatement statement = connection.prepareStatement(deleteCartQuery)) {
        statement.setString(1, currentUser);
        statement.executeUpdate();
    }
}




private void createLoginScene() {
    
    currentUser = null; 
    showAlert11("Logout", "You have been logged out successfully.", Alert.AlertType.INFORMATION);
    Main mainApp = new Main(); 
    mainApp.start(new Stage());
    window.close();  
}


private void showInformationAlert1(String title, String message) {
    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.showAndWait();
}


private void showErrorAlert1(String title, String message) {
    Alert alert = new Alert(Alert.AlertType.ERROR);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.showAndWait();
}


private void showInformationAlert(String title, String message) {
    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.showAndWait();
}


private void showErrorAlert(String title, String message) {
    Alert alert = new Alert(Alert.AlertType.ERROR);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.showAndWait();
}


private void showAlert(String title, String message, Alert.AlertType alertType) {
    Alert alert = new Alert(alertType);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.showAndWait();
}

public static void main(String[] args) {
    launch(args);
}

// Kelas Product untuk menyimpan data produk bunga
public static class Product {
    private final SimpleStringProperty name;
    private final SimpleStringProperty type;
    private final SimpleStringProperty price;
    private int quantity;

    public Product(String name, String type, String price, int i) {
        this.name = new SimpleStringProperty(name);
        this.type = new SimpleStringProperty(type);
        this.price = new SimpleStringProperty(price);
        this.quantity = quantity;
    }

    public int getQuantity() {
		// TODO Auto-generated method stub
		return 0;
	}
    
    public void setQuantity(int quantity) {
    	this.quantity = quantity;
    }

	public String getName() {
        return name.get();
    }

    public String getType() {
        return type.get();
    }

    public String getPrice() {
        return price.get();
    }

    public SimpleStringProperty nameProperty() {
        return name;
    }

    public SimpleStringProperty typeProperty() {
        return type;
    }

    public SimpleStringProperty priceProperty() {
        return price;
    }
}



}