import javafx.application.Application;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AdminDashboard extends Application {

    private Stage window;
    private Scene flowerListScene;
    private TableView<Flower> flowerTable;
    private ObservableList<Flower> flowerData;
    private TextField flowerNameField, flowerTypeField, flowerPriceField;
    private MenuBar menuBar;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        window = primaryStage;

        // Initialize the flower data
        flowerData = FXCollections.observableArrayList();
        loadFlowerDataFromDatabase();

        // Show the Flower List Scene
        showFlowerListScene();

        window.setTitle("Manage Products");
        window.show();
    }

    private void loadFlowerDataFromDatabase() {
        String query = "SELECT FlowerID, FlowerName, FlowerType, FlowerPrice FROM MsFlower";

        try (Connection connection = Connect.getConnection()) {
            System.out.println("Database connected successfully.");
            try (PreparedStatement statement = connection.prepareStatement(query);
                 ResultSet resultSet = statement.executeQuery()) {

                flowerData.clear();
                while (resultSet.next()) {
                    String id = resultSet.getString("FlowerID");
                    String name = resultSet.getString("FlowerName");
                    String type = resultSet.getString("FlowerType");
                    double price = resultSet.getDouble("FlowerPrice");
                    flowerData.add(new Flower(id, name, type, price));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to connect or load flower data from database.");
        }
    }


    private void showFlowerListScene() {
        // MenuBar with navigation items
        menuBar = new MenuBar();
        Menu pageMenu = new Menu("Account");
        MenuItem logoutMenuItem = new MenuItem("Log Out");

        pageMenu.getItems().addAll(logoutMenuItem);
        menuBar.getMenus().add(pageMenu);

        // Flower List Scene layout
        BorderPane flowerListPane = new BorderPane();
        flowerListPane.setTop(menuBar);  // Set the MenuBar at the top

        VBox flowerListVBox = new VBox(15);
        flowerListVBox.setAlignment(Pos.TOP_LEFT);

        // Label for Flower List
        Label flowerListLabel = new Label("Flower List");
        flowerListLabel.setFont(new Font("Arial", 20));
        flowerListLabel.setStyle("-fx-font-weight: bold;");

        // Label for Greeting (Welcome Admin)
        Label welcomeLabel = new Label("Welcome, Admin");
        welcomeLabel.setFont(new Font("Arial", 16));

        // Create TableView for Flowers
        flowerTable = new TableView<>();
        flowerTable.setItems(flowerData);

        // Create columns for TableView
        TableColumn<Flower, String> flowerIdColumn = new TableColumn<>("Flower ID");
        flowerIdColumn.setCellValueFactory(cellData -> cellData.getValue().flowerIdProperty());

        TableColumn<Flower, String> flowerNameColumn = new TableColumn<>("Flower Name");
        flowerNameColumn.setCellValueFactory(cellData -> cellData.getValue().flowerNameProperty());

        TableColumn<Flower, String> flowerTypeColumn = new TableColumn<>("Flower Type");
        flowerTypeColumn.setCellValueFactory(cellData -> cellData.getValue().flowerTypeProperty());

        TableColumn<Flower, Double> flowerPriceColumn = new TableColumn<>("Flower Price");
        flowerPriceColumn.setCellValueFactory(cellData -> cellData.getValue().flowerPriceProperty().asObject());

        // Add columns to TableView
        flowerTable.getColumns().addAll(flowerIdColumn, flowerNameColumn, flowerTypeColumn, flowerPriceColumn);

        // Flower detail input fields
        Label flowerDetailLabel = new Label("Flower Detail");
        flowerDetailLabel.setFont(new Font("Arial", 16));

        Label flowerNameLabel = new Label("Flower Name:");
        flowerNameField = new TextField();
        Label flowerTypeLabel = new Label("Flower Type:");
        flowerTypeField = new TextField();
        Label flowerPriceLabel = new Label("Flower Price:");
        flowerPriceField = new TextField();

        Button updateButton = new Button("Update Flower");
        Button deleteButton = new Button("Delete Flower");
        Button addButton = new Button("Add Flower");

        // Event handlers
        flowerTable.setOnMouseClicked(e -> handleFlowerSelection());

        updateButton.setOnAction(e -> handleUpdateFlower());
        deleteButton.setOnAction(e -> handleDeleteFlower());
        addButton.setOnAction(e -> handleAddFlower());

        // VBox for flower list on the left side
        flowerListVBox.getChildren().addAll(flowerListLabel, welcomeLabel, flowerTable);

        // Create a VBox for Flower Detail and Buttons on the right side
        VBox flowerDetailVBox = new VBox(15);
        flowerDetailVBox.setAlignment(Pos.TOP_LEFT);
        flowerDetailVBox.getChildren().addAll(
                flowerDetailLabel,
                flowerNameLabel, flowerNameField,
                flowerTypeLabel, flowerTypeField,
                flowerPriceLabel, flowerPriceField,
                updateButton, deleteButton, addButton
        );

        // Split the space between flower list and flower detail
        HBox mainLayout = new HBox(20);
        mainLayout.setAlignment(Pos.TOP_LEFT);
        mainLayout.getChildren().addAll(flowerListVBox, flowerDetailVBox);

        // Set main layout to center of BorderPane
        flowerListPane.setCenter(mainLayout);

        // Set the Scene
        flowerListScene = new Scene(flowerListPane, 800, 600);
        window.setScene(flowerListScene);  // Switch to Flower List Scene

        // Handle log out
        logoutMenuItem.setOnAction(e -> handleLogout());
    }

    private void handleAddFlower() {
        String name = flowerNameField.getText();
        String type = flowerTypeField.getText();
        String priceText = flowerPriceField.getText();

        // Validasi input
        if (name.isEmpty() || type.isEmpty() || priceText.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "All fields must be filled.");
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceText);
            if (price <= 0) {
                showAlert(Alert.AlertType.ERROR, "Price Error", "Price must be greater than 0.");
                return;
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Price Error", "Price must be a valid number.");
            return;
        }

        // Generate FlowerID
        String newFlowerID = generateFlowerID();

        // Query untuk menambahkan bunga
        String query = "INSERT INTO MsFlower (FlowerID, FlowerName, FlowerType, FlowerPrice) VALUES (?, ?, ?, ?)";

        try (Connection connection = Connect.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, newFlowerID);
            statement.setString(2, name);
            statement.setString(3, type);
            statement.setDouble(4, price);
            statement.executeUpdate();

            loadFlowerDataFromDatabase(); // Refresh data di table
            showAlert(Alert.AlertType.INFORMATION, "Add Successful", "New flower added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to add flower to database.");
        }
    }
    
    private String generateFlowerID() {
        String prefix = "FL"; // Prefix untuk FlowerID
        int maxId = 0;

        // Cari nilai maksimum FlowerID di database
        String query = "SELECT FlowerID FROM MsFlower";

        try (Connection connection = Connect.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                String currentId = resultSet.getString("FlowerID");

                // Ambil angka di akhir ID
                if (currentId.startsWith(prefix)) {
                    int currentNumber = Integer.parseInt(currentId.substring(prefix.length()));
                    maxId = Math.max(maxId, currentNumber);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Generate ID baru dengan increment
        int newIdNumber = maxId + 1;
        return String.format("%s%03d", prefix, newIdNumber); // Format: FLW001, FLW002, ...
    }




    private void handleUpdateFlower() {
        Flower selectedFlower = flowerTable.getSelectionModel().getSelectedItem();

        if (selectedFlower == null) {
            showAlert(Alert.AlertType.ERROR, "No Flower Selected", "Please select a flower from the list.");
            return;
        }

        String name = flowerNameField.getText();
        String type = flowerTypeField.getText();
        String priceText = flowerPriceField.getText();

        if (name.isEmpty() || type.isEmpty() || priceText.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "All fields must be filled.");
            return;
        }

        double price;
        try {
            price = Double.parseDouble(priceText);
            if (price <= 0) {
                showAlert(Alert.AlertType.ERROR, "Price Error", "Price must be greater than 0.");
                return;
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Price Error", "Price must be a valid number.");
            return;
        }

        String query = "UPDATE MsFlower SET FlowerName = ?, FlowerType = ?, FlowerPrice = ? WHERE FlowerID = ?";

        try (Connection connection = Connect.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, name);
            statement.setString(2, type);
            statement.setDouble(3, price);
            statement.setString(4, selectedFlower.flowerIdProperty().get());
            statement.executeUpdate();

            loadFlowerDataFromDatabase();
            showAlert(Alert.AlertType.INFORMATION, "Update Successful", "Flower updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to update flower in database.");
        }
    }

    private void handleDeleteFlower() {
        Flower selectedFlower = flowerTable.getSelectionModel().getSelectedItem();

        if (selectedFlower == null) {
            showAlert(Alert.AlertType.ERROR, "No Flower Selected", "Please select a flower from the list.");
            return;
        }

        String query = "DELETE FROM MsFlower WHERE FlowerID = ?";

        try (Connection connection = Connect.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, selectedFlower.flowerIdProperty().get());
            statement.executeUpdate();

            loadFlowerDataFromDatabase();
            showAlert(Alert.AlertType.INFORMATION, "Delete Successful", "Flower deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to delete flower from database.");
        }
    }

    private void handleFlowerSelection() {
        Flower selectedFlower = flowerTable.getSelectionModel().getSelectedItem();

        if (selectedFlower != null) {
            // Update the flower detail fields when a flower is selected
            flowerNameField.setText(selectedFlower.getFlowerName());
            flowerTypeField.setText(selectedFlower.getFlowerType());
            flowerPriceField.setText(String.valueOf(selectedFlower.getFlowerPrice()));
        }
    }

    private void handleLogout() {
        showAlert(Alert.AlertType.INFORMATION, "Logout", "You have been logged out successfully.");
            createLoginScene();
      // Menutup jendela saat ini
    }
    
    private void createLoginScene() {
        // Atur ulang user yang sedang login
        Object currentUser = null;

        // Tampilkan alert untuk logout
        showAlert(Alert.AlertType.INFORMATION, "You have been logged out successfully.", "Logout");

        // Buat instance baru dari aplikasi utama
        Main mainApp = new Main();
        try {
            // Mulai ulang aplikasi dari Main
            mainApp.start(new Stage());
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Failed to restart the application.", "Error");
        }

        // Tutup jendela saat ini
        window.close();
    }


    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Flower class with properties
    public static class Flower {
        private StringProperty flowerId;
        private StringProperty flowerName;
        private StringProperty flowerType;
        private DoubleProperty flowerPrice;

        public Flower(String flowerId, String flowerName, String flowerType, double flowerPrice) {
            this.flowerId = new SimpleStringProperty(flowerId);
            this.flowerName = new SimpleStringProperty(flowerName);
            this.flowerType = new SimpleStringProperty(flowerType);
            this.flowerPrice = new SimpleDoubleProperty(flowerPrice);
        }

        public StringProperty flowerIdProperty() {
            return flowerId;
        }


        public StringProperty flowerNameProperty() {
            return flowerName;
        }

        public StringProperty flowerTypeProperty() {
            return flowerType;
        }

        public DoubleProperty flowerPriceProperty() {
            return flowerPrice;
        }

        public String getFlowerName() {
            return flowerName.get();
        }

        public void setFlowerName(String name) {
            this.flowerName.set(name);
        }

        public String getFlowerType() {
            return flowerType.get();
        }

        public void setFlowerType(String type) {
            this.flowerType.set(type);
        }

        public double getFlowerPrice() {
            return flowerPrice.get();
        }

        public void setFlowerPrice(double price) {
            this.flowerPrice.set(price);
        }
    }
}
