import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.geometry.Pos;

public class Main extends Application {
private Stage window;
private Scene loginScene, registerScene;
private MenuBar menuBar;
private MenuItem loginMenuItem, registerMenuItem;
private TextField emailField;
private PasswordField passwordField;




@Override
public void start(Stage primaryStage) {
    window = primaryStage;
    UserDAO userDAO = new UserDAO(Connect.getConnection());
    
    menuBar = new MenuBar();
    Menu pageMenu = new Menu("Page");
    loginMenuItem = new MenuItem("Login");
    registerMenuItem = new MenuItem("Register");
    pageMenu.getItems().addAll(loginMenuItem, registerMenuItem);
    menuBar.getMenus().add(pageMenu);

    // Event handling untuk navigasi
    loginMenuItem.setOnAction(e -> {
        if (window.getScene() != loginScene) {
            createLoginScene();
            window.setScene(loginScene);
        }
    });

    registerMenuItem.setOnAction(e -> {
        if (window.getScene() != registerScene) {
            createRegisterScene();
            window.setScene(registerScene);
        }
    });

   
    BorderPane initialPane = new BorderPane();
    initialPane.setTop(menuBar);
    Scene initialScene = new Scene(initialPane, 400, 400);
    window.setScene(initialScene);
    window.setTitle("Login and Register Navigation");
    window.show();
}

private void createLoginScene() {
    GridPane loginGrid = new GridPane();
    loginGrid.setHgap(10);
    loginGrid.setVgap(10);
    loginGrid.setAlignment(Pos.CENTER);

    Label loginLabel = new Label("Login");
    loginLabel.setFont(new Font("Arial", 30));

    Label emailLabel = new Label("Email:");
    emailField = new TextField();
    Label passwordLabel = new Label("Password:");
    passwordField = new PasswordField();
    Button loginButton = new Button("Login");

   
    loginGrid.add(loginLabel, 0, 0, 2, 1);
    loginGrid.add(emailLabel, 0, 1);
    loginGrid.add(emailField, 1, 1);
    loginGrid.add(passwordLabel, 0, 2);
    loginGrid.add(passwordField, 1, 2);
    loginGrid.add(loginButton, 1, 3);

   
    loginButton.setOnAction(e -> handleLogin());

    
    BorderPane loginPane = new BorderPane();
    loginPane.setTop(menuBar);
    loginPane.setCenter(loginGrid);

    loginScene = new Scene(loginPane, 400, 400);
    window.setTitle("Login");
}


private void handleLogin() {
    String userEmail = emailField.getText();
    String userPassword = passwordField.getText();

   
    if (userEmail.isEmpty() || userPassword.isEmpty()) {
        showAlert(Alert.AlertType.ERROR, "Validation Error!", "Please enter your email and password.");
        return;
    }

   
    UserDAO userDAO = new UserDAO(Connect.getConnection());

    if (userDAO.validateLogin(userEmail, userPassword)) {
        String role = userDAO.getUserRole(userEmail);
        
      

        if (role != null) {
            if (role.equalsIgnoreCase("admin")) {
                showAlert(Alert.AlertType.INFORMATION, "Login Successful", "Welcome, Admin!");
                new AdminDashboard().start(window); // Pastikan class AdminDashboard ada
            } else if (role.equalsIgnoreCase("customer")) {
                showAlert(Alert.AlertType.INFORMATION, "Login Successful", "Welcome, Customer!");
                new CustomerDashboard().start(window); // Pastikan class CustomerDashboard ada
            } else {
                showAlert(Alert.AlertType.ERROR, "Login Failed", "User role not recognized.");
            }
        } else {
            showAlert(Alert.AlertType.ERROR, "Login Failed", "Unable to determine user role.");
        }
    } else {
        showAlert(Alert.AlertType.ERROR, "Login Failed", "Invalid email or password.");
    }
}






private void createRegisterScene() {
   
    GridPane registerGrid = new GridPane();
    registerGrid.setHgap(10);
    registerGrid.setVgap(10);
    registerGrid.setAlignment(Pos.CENTER);

    TextField usernameField = new TextField();
    emailField = new TextField();
    passwordField = new PasswordField();
    PasswordField confirmPasswordField = new PasswordField();
    TextArea addressField = new TextArea();
    TextField phoneNumberField = new TextField();

   
    ColumnConstraints col1 = new ColumnConstraints();
    col1.setPercentWidth(40);  
    ColumnConstraints col2 = new ColumnConstraints();
    col2.setPercentWidth(60); 
    registerGrid.getColumnConstraints().addAll(col1, col2);

    Label registerLabel = new Label("Register");
    registerLabel.setFont(new Font("Arial", 30));

    Label emailLabel = new Label("Email:");
    Label usernameLabel = new Label("Username:");
    Label passwordLabel = new Label("Password:");
    Label confirmPasswordLabel = new Label("Confirm Password:");
    Label addressLabel = new Label("Address:");
    Label phoneLabel = new Label("Phone Number:");
    CheckBox agreeCheckBox = new CheckBox("I agree to create an account");
    Button registerButton = new Button("Register");

    // Menambah komponen ke GridPane
    registerGrid.add(registerLabel, 0, 0, 2, 1);  
    registerGrid.add(emailLabel, 0, 1);
    registerGrid.add(emailField, 1, 1);
    registerGrid.add(usernameLabel, 0, 2);
    registerGrid.add(usernameField, 1, 2);
    registerGrid.add(passwordLabel, 0, 3);
    registerGrid.add(passwordField, 1, 3);
    registerGrid.add(confirmPasswordLabel, 0, 4);
    registerGrid.add(confirmPasswordField, 1, 4);
    registerGrid.add(addressLabel, 0, 5);
    registerGrid.add(addressField, 1, 5);
    registerGrid.add(phoneLabel, 0, 6);
    registerGrid.add(phoneNumberField, 1, 6);
    registerGrid.add(agreeCheckBox, 1, 7);
    registerGrid.add(registerButton, 1, 8);

    // Event handling untuk tombol register
    registerButton.setOnAction(e -> handleRegister(usernameField, emailField, passwordField, confirmPasswordField, addressField, phoneNumberField, agreeCheckBox));

    BorderPane registerPane = new BorderPane();
    registerPane.setTop(menuBar);
    registerPane.setCenter(registerGrid);

    registerScene = new Scene(registerPane, 400, 600);
    window.setTitle("Register");
}

private void handleRegister(
	    TextField usernameField,
	    TextField emailField,
	    PasswordField passwordField,
	    PasswordField confirmPasswordField,
	    TextArea addressField,
	    TextField phoneNumberField,
	    CheckBox agreeCheckBox
	) {
	    String username = usernameField.getText();
	    String email = emailField.getText();
	    String password = passwordField.getText();
	    String confirmPassword = confirmPasswordField.getText();
	    String phoneNumber = phoneNumberField.getText();
	    String address = addressField.getText();

	    // Validasi input
	    if (!agreeCheckBox.isSelected()) {
	        showAlert(Alert.AlertType.ERROR, "Validation Error", "You must agree to create an account.");
	        return;
	    }

	    if (username.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || phoneNumber.isEmpty() || address.isEmpty()) {
	        showAlert(Alert.AlertType.ERROR, "Validation Error", "All fields must be filled.");
	        return;
	    }

	    if (username.length() < 4 || username.length() > 20) {
	        showAlert(Alert.AlertType.ERROR, "Username Error", "Username must be between 4 and 20 characters.");
	        return;
	    }

	    if (!password.equals(confirmPassword)) {
	        showAlert(Alert.AlertType.ERROR, "Password Error", "Password and Confirm Password must be the same.");
	        return;
	    }

	    if (password.length() < 8) {
	        showAlert(Alert.AlertType.ERROR, "Password Error", "Password must be at least 8 characters.");
	        return;
	    }

	    if (phoneNumber.length() < 8 || phoneNumber.length() > 20 || !phoneNumber.matches("[0-9]+")) {
	        showAlert(Alert.AlertType.ERROR, "Phone Number Error", "Phone number must be between 8 and 20 digits.");
	        return;
	    }

	    try {
	        // Memasukkan data ke database melalui UserDAO
	        UserDAO userDAO = new UserDAO(Connect.getConnection());
	        boolean isRegistered = userDAO.registerUser(username, password, email, phoneNumber, address);

	        if (isRegistered) {
	            showAlert(Alert.AlertType.INFORMATION, "Registration Successful", "User registered successfully!");
	        } else {
	            showAlert(Alert.AlertType.ERROR, "Registration Failed", "Failed to register user. Please try again.");
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        showAlert(Alert.AlertType.ERROR, "Database Error", "Error connecting to database: " + e.getMessage());
	    }
	}





private void showAlert(Alert.AlertType alertType, String title, String message) {
    Alert alert = new Alert(alertType);
    alert.setTitle(title);
    alert.setContentText(message);
    alert.showAndWait();
}

public static void main(String[] args) {
    launch(args);
}



} 