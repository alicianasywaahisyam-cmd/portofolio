import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Connect {
    private static Connect instance;
    private Connection con;

    private Connect() {
        try {
            String url = "jdbc:mysql://localhost:3306/floraartistry"; 
            String USER = "root";
            String PASSWORD = "";
            con = DriverManager.getConnection(url, USER, PASSWORD);
            System.out.println("Database connection established.");
        } catch (SQLException e) {
            System.out.println("Failed to connect to the database.");
            e.printStackTrace();
        }
    }

    public static Connect getInstance() {
        if (instance == null) {
            instance = new Connect();
        }
        return instance;
    }

    public static Connection getConnection() {
        try {
            if (getInstance().con == null || getInstance().con.isClosed()) {
                String url = "jdbc:mysql://localhost:3306/floraartistry"; 
                String USER = "nasywaa";
                String PASSWORD = "Limn4syw4";
                getInstance().con = DriverManager.getConnection(url, USER, PASSWORD);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return getInstance().con;
    }

    
    public PreparedStatement prepareStatement(String sql) throws SQLException {
        if (con == null || con.isClosed()) {
            throw new SQLException("Database connection is not available.");
        }
        return con.prepareStatement(sql);
    }


    public static void closeConnection() {
        try {
            if (getInstance().con != null && !getInstance().con.isClosed()) {
                getInstance().con.close();
                System.out.println("Database connection closed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
